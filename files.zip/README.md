# The FACE — Live News Setup (Vercel)

Panduan deploy fitur live-fetch berita ke Vercel.

## Struktur file

```
theface-vercel/
├── index.html         ← website utama (sebelumnya theface.html)
├── api/
│   └── news.js        ← serverless function (headless browser scraper)
├── package.json        ← dependency: puppeteer-core + @sparticuz/chromium
├── vercel.json          ← konfigurasi timeout + Cron job per jam
└── .gitignore
```

## Langkah deploy

### 1. Push ke GitHub
```bash
cd theface-vercel
git init
git add .
git commit -m "Add live news API"
git remote add origin <URL_REPO_GITHUB_KAMU>
git push -u origin main
```

### 2. Import ke Vercel
- Buka [vercel.com/new](https://vercel.com/new)
- Import repo GitHub yang baru dibuat
- **Pastikan project sudah di plan Pro** (dibutuhkan untuk timeout function >10 detik)
- Klik Deploy

### 3. Vercel otomatis akan:
- Install dependency dari `package.json`
- Deploy `api/news.js` sebagai serverless function
- Mengaktifkan Cron job di `vercel.json` (jalan tiap jam, pukul :00)
- Serve `index.html` sebagai halaman utama

### 4. Cek hasil
- Buka `https://<domain-kamu>.vercel.app`
- Buka tab **Berita Hari Ini**
- Lihat titik indikator di atas daftar berita:
  - 🟢 **Hijau** = data live berhasil di-fetch dari Detik.com
  - 🟡 **Kuning** = fallback ke data kurasi (live fetch gagal/timeout)
- Test manual: klik tombol "Refresh" di bar berita

### 5. Cek log Cron job
- Vercel Dashboard → Project kamu → tab **Cron Jobs**
- Lihat history eksekusi `/api/news?cron=1` setiap jam

## Cara kerja singkat

1. Saat halaman dibuka, browser memanggil `/api/news`
2. Function di server membuka **headless Chromium**, mengunjungi `detik.com/tag/dpr-ri`
3. Mengambil **judul + link** berita yang relevan dengan DPR/politisi (tidak mengambil isi artikel — demi hak cipta)
4. Hasil di-cache selama ~55 menit supaya tidak buka browser baru di setiap klik visitor
5. Vercel Cron memanggil endpoint yang sama tiap jam untuk "memanaskan" cache duluan
6. Kalau scraping gagal (situs berubah struktur, timeout, dll), website otomatis fallback ke 14 berita kurasi manual yang sudah ada di dalam kode — **tidak akan pernah blank**

## Menambah sumber lain (Kompas, CNN, dst)

Edit `api/news.js`, tambahkan objek baru di array `SOURCES`:

```js
{
  id: "kompas",
  name: "Kompas.com",
  url: "https://www.kompas.com/tag/dpr-ri",
  extract: () => { /* selector khusus Kompas, perlu inspeksi DOM dulu */ }
}
```

⚠️ **Penting**: setiap sumber baru butuh inspeksi manual struktur HTML-nya (DOM selector berbeda-beda per situs, dan situs modern sering pakai class name yang di-generate otomatis/berubah saat redeploy mereka). Uji satu-satu sebelum menambahkan ke production.

## Troubleshooting

| Masalah | Kemungkinan sebab |
|---|---|
| Selalu fallback ke data kurasi | Function timeout (cek plan Vercel = Pro), atau selector Detik berubah |
| Function error "Cannot find module" | `npm install` belum jalan — cek Vercel build log |
| Cron tidak jalan | Fitur Cron butuh plan Pro/Enterprise, cek di Settings → Cron Jobs |
| Browser launch gagal | `@sparticuz/chromium` versi tidak cocok dengan runtime Node Vercel — cek versi di `package.json` |

## Batasan yang disengaja

- Hanya mengambil **judul + link**, bukan isi/ringkasan artikel (kepatuhan hak cipta)
- Hanya 1 sumber aktif (Detik.com) untuk versi awal — sumber lain bisa ditambah setelah ini terbukti stabil
- Cache 55 menit berarti data tidak benar-benar "real-time per detik", tapi cukup dekat dengan siklus refresh per jam yang diminta
